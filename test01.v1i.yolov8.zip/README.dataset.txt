# test01 > 2023-06-08 3:52pm
https://universe.roboflow.com/worktest-n3tve/test01-mzjbt

Provided by a Roboflow user
License: CC BY 4.0

